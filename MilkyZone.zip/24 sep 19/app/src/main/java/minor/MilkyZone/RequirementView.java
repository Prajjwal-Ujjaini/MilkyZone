package minor.MilkyZone;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class RequirementView extends AppCompatActivity {

    private DatabaseReference databaseReference;
    private ArrayList<Customer> dataSource;
    private Activity context;
    private ListView listView;
    private RequirementAdapter requirementAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_requirement_view);

        databaseReference = FirebaseDatabase.getInstance().getReference("CustomerTable");
        context = RequirementView.this;
        dataSource = new ArrayList<>();
        listView = findViewById(R.id.requirementList);
    }

    @Override
    protected void onStart() {
        super.onStart();
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                try {
                    dataSource.clear();
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        Customer user = snapshot.getValue(Customer.class);
                        dataSource.add(user);
                    }

                    requirementAdapter = new RequirementAdapter(context, dataSource);
                    listView.setAdapter(requirementAdapter);

                } catch (Exception e) {
                    Log.e("Exception", e.toString());
                    Toast.makeText(context, e.toString(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(context, databaseError.toString(), Toast.LENGTH_SHORT).show();
            }
        });
    }

}
