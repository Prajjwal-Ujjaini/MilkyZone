package minor.MilkyZone;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class RequirementAdapter extends ArrayAdapter<Customer> {
    private Activity context;
    List<Customer> CustomerTable;

    public RequirementAdapter(Activity context, List<Customer> CustomerTable) {
        super(context, R.layout.requirment_list, CustomerTable);
        this.context = context;
        this.CustomerTable = CustomerTable;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        LayoutInflater inflater = context.getLayoutInflater();
        View listItem = inflater.inflate(R.layout.requirment_list, null);

        TextView txtName = listItem.findViewById(R.id.tvNameReq);
        TextView txtMno = listItem.findViewById(R.id.tvMonReq);
        TextView txtAddress = listItem.findViewById(R.id.tvAddressReq);
        TextView txtMilk = listItem.findViewById(R.id.tvMilkReq);
        TextView txtBread = listItem.findViewById(R.id.tvBreadReq);

        Customer customer = CustomerTable.get(position);

        txtName.setText("Name:"+customer.getName());
        txtMno.setText("Phone no.:"+customer.getMno());
        txtAddress.setText("Address:"+customer.getAddress());
        txtMilk.setText("milk="+customer.getMilk());
        txtBread.setText("Bread="+customer.getBread());

        return listItem;
    }
}
