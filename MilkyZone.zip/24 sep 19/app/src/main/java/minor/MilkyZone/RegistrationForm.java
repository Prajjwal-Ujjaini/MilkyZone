package minor.MilkyZone;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class RegistrationForm extends AppCompatActivity {

    FirebaseAuth firebaseAuth;
    FirebaseUser firebaseUser;
    DatabaseReference databaseReference;
    Activity context;
    ProgressBar progressBar;

    String stEmail,stPassword ,customerId;
    EditText etName,etMno, etAddress, etDob;
    Button btRegistration;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration_form);

        getSupportActionBar().setTitle("Registration");

        find_id();
        stEmail= getIntent().getExtras().getString("email");
        stPassword=getIntent().getExtras().getString("password");
        customerId=firebaseUser.getUid();
    }

    public void find_id() {
        firebaseAuth=FirebaseAuth.getInstance();
        firebaseUser=firebaseAuth.getCurrentUser();
        databaseReference = FirebaseDatabase.getInstance().getReference("CustomerTable");
        context = RegistrationForm.this;

        progressBar=findViewById(R.id.pbReg);
        etName = findViewById(R.id.etName);
        etMno = findViewById(R.id.etMno);
        etAddress = findViewById(R.id.etAddress);
        etDob = findViewById(R.id.etDob);
        btRegistration = findViewById(R.id.btRigristration);
    }

    public void addCustomer(View view) {
        String name,address,dob,mno;
        name= etName.getText().toString().trim();
        mno=etMno.getText().toString().trim();
        address= etAddress.getText().toString().trim();
        dob= etDob.getText().toString().trim();

        if (mno.length() < 10) {
            Toast.makeText(getApplicationContext(), "Please Enter 10 digit mobile number", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!TextUtils.isEmpty(name) && !TextUtils.isEmpty(mno) && !TextUtils.isEmpty(address)
                && !TextUtils.isEmpty(dob)){

            //String uid = databaseReference.push().getKey();
            Customer customer = new Customer(customerId, name, stEmail,mno, stPassword, address, dob);
            progressBar.setVisibility(View.VISIBLE);
            databaseReference.child(customerId).setValue(customer);
            progressBar.setVisibility(View.GONE);
            Toast.makeText(this, "Regristration sucessful", Toast.LENGTH_SHORT).show();
            etName.setText("");
            etMno.setText("");
            etAddress.setText("");
            etDob.setText("");

            Intent intent=new Intent(this,CustomerDashBoard.class);
            startActivity(intent);
        } else {
            Toast.makeText(this, "Please enter data first", Toast.LENGTH_SHORT).show();
            progressBar.setVisibility(View.GONE);

        }
    }

}
