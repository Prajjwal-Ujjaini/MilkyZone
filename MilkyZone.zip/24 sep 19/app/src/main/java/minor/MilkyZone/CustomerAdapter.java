package minor.MilkyZone;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.lang.reflect.Array;
import java.util.List;

public class CustomerAdapter extends ArrayAdapter<Customer> {
    private Activity context;
    List<Customer> CustomerTable;

    public CustomerAdapter(Activity context, List<Customer> CustomerTable) {
        super(context, R.layout.customer_list, CustomerTable);
        this.context = context;
        this.CustomerTable = CustomerTable;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        LayoutInflater inflater = context.getLayoutInflater();
        View listItem = inflater.inflate(R.layout.customer_list, null);

        TextView txtName = listItem.findViewById(R.id.textViewName);
        TextView txtEmail = listItem.findViewById(R.id.textviewemail);
        TextView txtMno = listItem.findViewById(R.id.textviewnumber);
        TextView txtAddress = listItem.findViewById(R.id.textViewAddress);
        TextView txtDob = listItem.findViewById(R.id.textViewDob);
        TextView txtUid = listItem.findViewById(R.id.textViewUid);

        Customer customer = CustomerTable.get(position);

        txtName.setText("Name:"+customer.getName());
        txtEmail.setText("Email:"+customer.getEmail());
        txtMno.setText("Phone no.:"+customer.getMno());
        txtAddress.setText("Address:"+customer.getAddress());
        txtDob.setText("Dob:"+customer.getDob());
        txtUid.setText("Uid:"+customer.getUid());


        return listItem;
    }
}
