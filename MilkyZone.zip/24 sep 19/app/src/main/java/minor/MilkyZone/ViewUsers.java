package minor.MilkyZone;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class ViewUsers extends AppCompatActivity {

    private DatabaseReference databaseReference;
    private ArrayList<Customer> dataSource;
    private Activity context;
    private ListView listView;
    private CustomerAdapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_users);

        databaseReference = FirebaseDatabase.getInstance().getReference("CustomerTable");
        context = ViewUsers.this;
        dataSource = new ArrayList<>();
        listView = findViewById(R.id.userList);
    }


    @Override
    protected void onStart() {
        super.onStart();
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                try {
                    dataSource.clear();
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        Customer user = snapshot.getValue(Customer.class);
                        dataSource.add(user);
                    }
                    adapter = new CustomerAdapter(context, dataSource);
                    listView.setAdapter(adapter);
                    listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                            Customer customer=dataSource.get(position);
                            CallUpdateAndDeleteDialog(customer.getUid(), customer.getName(),customer.getEmail(),customer.getMno());

                        }
                    });
                } catch (Exception e) {
                    Log.e("Exception", e.toString());
                    Toast.makeText(context, e.toString(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(context, databaseError.toString(), Toast.LENGTH_SHORT).show();
            }
        });
    }



    private void CallUpdateAndDeleteDialog(final String userid, String username, final String email, String monumber) {
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(ViewUsers.this);
        LayoutInflater inflater = getLayoutInflater();

        final View dialogView = inflater.inflate(R.layout.update_dialog, null);
        dialogBuilder.setView(dialogView);
        //Access Dialog views

        final TextView updateTextname = (TextView) dialogView.findViewById(R.id.updateTextname);
        final TextView updateTextemail = (TextView) dialogView.findViewById(R.id.updateTextemail);
        final TextView updateTextmobileno = (TextView) dialogView.findViewById(R.id.updateTextmobileno);

        updateTextname.setText(username);
        updateTextemail.setText(email);
        updateTextmobileno.setText(monumber);

        final Button buttonDelete = (Button) dialogView.findViewById(R.id.buttonDeleteUser);
        //username for set dialog title
        dialogBuilder.setTitle(username);
        final AlertDialog b = dialogBuilder.create();
        b.show();


        // Click listener for Delete data
        buttonDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Method for delete data
                deleteUser(userid);
                b.dismiss();
            }
        });
    }


    private boolean deleteUser(String id) {
        //getting the specified User reference
        DatabaseReference DeleteReference = FirebaseDatabase.getInstance().getReference("CustomerTable").child(id);
        //removing User
        DeleteReference.removeValue();
        Toast.makeText(getApplicationContext(), "User Deleted", Toast.LENGTH_LONG).show();
        return true;
    }


}
