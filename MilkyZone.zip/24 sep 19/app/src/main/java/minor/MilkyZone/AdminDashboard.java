package minor.MilkyZone;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class AdminDashboard extends AppCompatActivity {

    FirebaseAuth firebaseAuth;
    FirebaseUser firebaseUser;
    Button btAdminSignout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_dashboard);


        firebaseAuth= FirebaseAuth.getInstance();
        firebaseUser= FirebaseAuth.getInstance().getCurrentUser();

        btAdminSignout=findViewById(R.id.btAdminSignOut);

        btAdminSignout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                firebaseAuth.signOut();
                finish();
                Intent intent = new Intent(AdminDashboard.this,MainActivity.class);
                startActivity(intent);
                Toast.makeText(AdminDashboard.this, "Logged Out Successfully.", Toast.LENGTH_LONG).show();
            }
        });
    }


    public void customerDetails(View view) {
        Intent intent = new Intent(AdminDashboard.this, ViewUsers.class);
        startActivity(intent);
    }


    public void todayReq(View view) {
        Intent intent = new Intent(AdminDashboard.this, RequirementView.class);
        startActivity(intent);
    }


}
