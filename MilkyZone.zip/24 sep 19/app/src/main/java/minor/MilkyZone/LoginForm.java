package minor.MilkyZone;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class LoginForm extends AppCompatActivity {

    private FirebaseAuth firebaseAuth;
    private EditText etLoginEmail, etLoginPwd;
    private Button btLogin;
    ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_form);

        getSupportActionBar().setTitle("Login");

        etLoginEmail = findViewById(R.id.etLoginEmail);
        etLoginPwd = findViewById(R.id.etLoginPwd);
        btLogin = findViewById(R.id.btLoginBtn);
        progressBar=findViewById(R.id.pblogin);

        firebaseAuth= FirebaseAuth.getInstance();


        btLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email,password;
                email=etLoginEmail.getText().toString().trim();
                password=etLoginPwd.getText().toString().trim();

                if (TextUtils.isEmpty(email)){
                    Toast.makeText(LoginForm.this, "Please Enter Email", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (password.isEmpty()){
                    Toast.makeText(LoginForm.this, "Please Enter Password", Toast.LENGTH_SHORT).show();
                    return;
                }
                progressBar.setVisibility(View.VISIBLE);
                firebaseAuth.signInWithEmailAndPassword(email,password)
                        .addOnCompleteListener(LoginForm.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()){
                                    Toast.makeText(LoginForm.this, "Login Sucessfull", Toast.LENGTH_SHORT).show();

                                    progressBar.setVisibility(View.GONE);
                                    Intent intent=new Intent(LoginForm.this,CustomerDashBoard.class);
                                    startActivity(intent);
                                }else {
                                    Toast.makeText(LoginForm.this, "Login Fail:please check Email or password", Toast.LENGTH_SHORT).show();
                                    progressBar.setVisibility(View.GONE);
                                }
                            }
                        });

            }
        });
    }



    public void goToEmailAuthentication(View view) {
        //this function forward page to email authentication

        startActivity(new Intent(getApplicationContext(), AuthenticationEmail.class));
    }
}

