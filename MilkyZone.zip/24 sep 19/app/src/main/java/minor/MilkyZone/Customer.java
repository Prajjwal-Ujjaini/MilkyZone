package minor.MilkyZone;

import com.google.firebase.database.Exclude;

import java.util.HashMap;
import java.util.Map;

public class Customer {
    String uid, name, email,mno, password, address, dob;
    int milk,bread;


    public Customer() {
    }


    public Customer(String uid, String name, String email, String mno) {
        this.uid = uid;
        this.name = name;
        this.email = email;
        this.mno = mno;
    }

    public Customer(String uid, String name, String email, String mno, String password, String address, String dob) {
        this.uid = uid;
        this.name = name;
        this.email = email;
        this.mno = mno;
        this.password = password;
        this.address = address;
        this.dob = dob;
    }


    public void updateQty(int milk,int bread){
        this.milk=milk;
        this.bread=bread;
    }

    public String getUid() {
        return uid;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getMno() {
        return mno;
    }

    public String getPassword() {
        return password;
    }

    public String getAddress() {
        return address;
    }

    public String getDob() {
        return dob;
    }

    public int getMilk() {
        return milk;
    }

    public int getBread() {
        return bread;
    }
}