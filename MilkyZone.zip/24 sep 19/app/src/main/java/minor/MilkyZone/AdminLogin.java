package minor.MilkyZone;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class AdminLogin extends AppCompatActivity {
    private FirebaseAuth firebaseAuth;
    private EditText etAdminLoginEmail, etAdminLoginPwd;
    private Button btAdminLogin;
    ProgressBar progressBar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_login);

        getSupportActionBar().setTitle("Admin Login");

        etAdminLoginEmail = findViewById(R.id.etAdminLoginEmail);
        etAdminLoginPwd = findViewById(R.id.etAdminLoginPwd);
        btAdminLogin = findViewById(R.id.btAdminLogin);
        progressBar=findViewById(R.id.pbAdminlogin);
        firebaseAuth= FirebaseAuth.getInstance();


        btAdminLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email,password;
                email=etAdminLoginEmail.getText().toString().trim();
                password=etAdminLoginPwd.getText().toString().trim();
                if (TextUtils.isEmpty(email)){
                    Toast.makeText(AdminLogin.this, "Please Enter Email", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (password.isEmpty()){
                    Toast.makeText(AdminLogin.this, "Please Enter Password", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (email.equals("vendoradmin@milkyzone.com") && (password.equals("123456789"))){
                    progressBar.setVisibility(View.VISIBLE);
                    firebaseAuth.signInWithEmailAndPassword(email,password)
                            .addOnCompleteListener(AdminLogin.this, new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    if (task.isSuccessful()){
                                        progressBar.setVisibility(View.GONE);
                                        Toast.makeText(AdminLogin.this, "Login Sucessfull", Toast.LENGTH_SHORT).show();
                                        Toast.makeText(AdminLogin.this, "You are Admin login", Toast.LENGTH_SHORT).show();

                                        Intent intent=new Intent(AdminLogin.this,AdminDashboard.class);
                                        startActivity(intent);
                                    }else {
                                        Toast.makeText(AdminLogin.this, "Login Fail:please check Email or password Please enter vaild Afdmin pass", Toast.LENGTH_SHORT).show();
                                        progressBar.setVisibility(View.GONE);
                                    }
                                }
                            });

                }else {
                    Toast.makeText(AdminLogin.this, "Please Enter Valid Admin User name and Password", Toast.LENGTH_SHORT).show();
                    progressBar.setVisibility(View.GONE);
                }

            }
        });
    }
}
