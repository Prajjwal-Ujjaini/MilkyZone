package minor.MilkyZone;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.TabActivity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class CustomerDashBoard extends AppCompatActivity   {

    LinearLayout profile,home,aboutus;
    //Profile
    TextView tvShowNameProfile,tvShowEmailProfile,tvShowIdProfile,tvShowMnoProfile;
    Button btSignout,btUpdateProfile,btDetet;

    //Home
    FirebaseAuth firebaseAuth;
    FirebaseUser firebaseUser;
    DatabaseReference databaseReference;

    Button btSubmitQuantity;
    TextView tvShowUserEmailHome,tvQtMilk ,tvQtBread;


    String customerId;
    int milk=0,bread= 0;

    //aboutus
    TextView tvAboutUs ,tvProfile,tvDailyRequirement;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_dash_board);

        getSupportActionBar().setTitle("Dashboard");

        profile=findViewById(R.id.layoutProfile);
        home=findViewById(R.id.layoutHome);
        aboutus=findViewById(R.id.layoutVendorDetails);

        //Home
        btSubmitQuantity=findViewById(R.id.btSubmitQuantity);
        tvShowUserEmailHome=findViewById(R.id.etShowEmailHome);
        tvQtMilk=findViewById(R.id.tvQtMilk);
        tvQtBread=findViewById(R.id.tvQtBread);

        //Profile
        //tvShowNameProfile=findViewById(R.id.tvShowNameProfile);
        tvShowEmailProfile=findViewById(R.id.tvShowEmailProfile);
        tvShowIdProfile=findViewById(R.id.tvShowIdProfile);
        //tvShowMnoProfile=findViewById(R.id.tvShowMnoProfile);

        btSignout=findViewById(R.id.btSignout);
       // btUpdateProfile=findViewById(R.id.btUpdateProfile);
        btDetet=findViewById(R.id.btDashboard);


        //AboutUs
        tvAboutUs=findViewById(R.id.tvAboutUs);
        tvProfile=findViewById(R.id.tvProfile);
        tvDailyRequirement=findViewById(R.id.tvDailyRequirement);


        firebaseAuth=FirebaseAuth.getInstance();
        firebaseUser=firebaseAuth.getCurrentUser();
        databaseReference= FirebaseDatabase.getInstance().getReference("CustomerTable");

        customerId=firebaseUser.getUid();


        //home
        tvShowUserEmailHome.setText("Successfully Logged In, Your Email = " + firebaseUser.getEmail());
        btSubmitQuantity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateQuantity(customerId,milk,bread);
            }
        });




        //profile
        //tvShowNameProfile.setText(firebaseUser.getDisplayName());
        tvShowEmailProfile.setText(firebaseUser.getEmail());
        tvShowIdProfile.setText(firebaseUser.getUid());
        //tvShowMnoProfile.setText(firebaseUser.getPhoneNumber());

        btSignout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                firebaseAuth.signOut();
                finish();
                Intent intent = new Intent(CustomerDashBoard.this,MainActivity.class);
                startActivity(intent);
                Toast.makeText(CustomerDashBoard.this, "Logged Out Successfully.", Toast.LENGTH_LONG).show();
            }
        });

        btDetet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //DatabaseReference dltUser=databaseReference.child(customerId);

                FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                if (user != null) {
                    user.delete()
                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if (task.isSuccessful()) {
                                        Toast.makeText(CustomerDashBoard.this, "Your profile is deleted:( Create a account now!", Toast.LENGTH_SHORT).show();
                                        Intent intent=new Intent(CustomerDashBoard.this,LoginForm.class);
                                        startActivity(intent);
                                    } else {
                                        Toast.makeText(CustomerDashBoard.this, "Failed to delete your account!", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });
                }
                Toast.makeText(CustomerDashBoard.this, "User deleted", Toast.LENGTH_SHORT).show();
            }
        });

        //Aboutus

        tvProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                profile.setVisibility(View.VISIBLE);
                home.setVisibility(View.GONE);
                aboutus.setVisibility(View.GONE);
            }
        });

        tvDailyRequirement.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                profile.setVisibility(View.GONE);
                home.setVisibility(View.VISIBLE);
                aboutus.setVisibility(View.GONE);
            }
        });

        tvAboutUs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                profile.setVisibility(View.GONE);
                home.setVisibility(View.GONE);
                aboutus.setVisibility(View.VISIBLE);
            }
        });
    }

    public void updateQuantity(String id,int milk, int bread) {

        DatabaseReference milkRef=databaseReference.child(id);

        Map<String,Object> updateQ=new HashMap<>();
        updateQ.put("milk",milk);
        updateQ.put("bread",bread);

        milkRef.updateChildren(updateQ);
        Toast.makeText(this, "your today's requirement is updated:Quantity updated", Toast.LENGTH_SHORT).show();
    }

    public void increaseMilk(View view) {
        milk=milk+1;
        displayMilk(milk);
        displayPriceMilk(milk);
    }
    public void decreaseMilk(View view) {
        if(milk>0){
            milk = milk - 1;
            displayMilk(milk);
            displayPriceMilk(milk);
        }else {
            Toast.makeText(this, "Sorry uhh cannot make quantity in negative ", Toast.LENGTH_SHORT).show();
        }
    }
    private void displayMilk(int number) {
        TextView displayInteger = findViewById(R.id.tvQtMilk);
        displayInteger.setText("" + number);
    }
    private void displayPriceMilk(int no){
        TextView d=findViewById(R.id.tvMilkPrice);
        d.setText("Milk =Rs."+10*no);
    }

    public void increaseBread(View view) {
        bread=bread+1;
        displayBread(bread);
        displayPriceBread(bread);
    }
    public void decreaseBread(View view) {
        if(bread>0){
            bread = bread - 1;
            displayBread(bread);
            displayPriceBread(bread);
        }else {
            Toast.makeText(this, "Sorry uhh cannot make quantity in negative ", Toast.LENGTH_SHORT).show();
        }
    }
    private void displayBread(int number) {
        TextView displayInteger = findViewById(R.id.tvQtBread);
        displayInteger.setText("" + number);
    }
    private void displayPriceBread(int no){
        TextView d=findViewById(R.id.tvBreadPrice);
        d.setText("Bread =Rs."+20*no);
    }


}
