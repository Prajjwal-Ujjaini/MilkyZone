package minor.MilkyZone;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import android.os.Process;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;


public class AuthenticationEmail extends AppCompatActivity {

    //this activity will authenticate the user email and then forward this page to regrtration

    EditText etEmail, etPwd;
    Button btGotoReg;
    FirebaseAuth firebaseAuth;
    ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_authentication_email);

        etEmail = findViewById(R.id.etEmail);
        etPwd = findViewById(R.id.etPwd);
        btGotoReg=findViewById(R.id.btGotoReg);
        progressBar=findViewById(R.id.pbAuthEmail);

        firebaseAuth = FirebaseAuth.getInstance();

        btGotoReg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String email,password;
                email = etEmail.getText().toString().trim();
                password = etPwd.getText().toString().trim();

                if(TextUtils.isEmpty(email)){
                    Toast.makeText(AuthenticationEmail.this, "Please enter email", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (TextUtils.isEmpty(password)){
                    Toast.makeText(AuthenticationEmail.this, "Please enter password", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (password.length() < 6) {
                    Toast.makeText(getApplicationContext(), "Password too short, enter minimum 6 characters!", Toast.LENGTH_SHORT).show();
                    return;
                }
                progressBar.setVisibility(View.VISIBLE);
                firebaseAuth.createUserWithEmailAndPassword(email,password)
                        .addOnCompleteListener(AuthenticationEmail.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {

                                if (task.isSuccessful()) {
                                    progressBar.setVisibility(View.GONE);
                                    Toast.makeText(AuthenticationEmail.this, "Successfully registered", Toast.LENGTH_LONG).show();
                                    Intent intent=new Intent(AuthenticationEmail.this,RegistrationForm.class);
                                    intent.putExtra("email", email);
                                    intent.putExtra("password", password);
                                    startActivity(intent);
                                } else {
                                    Toast.makeText(AuthenticationEmail.this, "Registration Error:please Check network again ", Toast.LENGTH_LONG).show();
                                    progressBar.setVisibility(View.GONE);
                                }
                            }
                        });
            }
        });
    }
}
